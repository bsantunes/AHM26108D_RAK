/*
 * Copyright 2017-2022 Morse Micro
 *
 */

#include <linux/module.h>

#define CREATE_TRACE_POINTS
#include "trace.h"
